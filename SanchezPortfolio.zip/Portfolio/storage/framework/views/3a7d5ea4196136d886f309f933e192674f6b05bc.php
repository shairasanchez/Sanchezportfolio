<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
    <title>Portfolio</title>

	<link rel="stylesheet" type="text/css" href="<?php echo e(url('public/frontend/style.css')); ?>">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet">
</head>
<body>
	<header>
		<nav>
			<ul>
				<li><a href="home">Homepage</a></li>
				<li><a href="about">About me Page</a></li>
				<li><a href="contact">Contacts</a></li>
			</ul>
		</nav>
	</header>

	<div id="home">
		<div class="text">
			<h1>
				<span>H</span>
				<span class="m-left">i</span>
				<span class="m-left">,</span>
				<br>
				<span>I</span>
				<span class="m-left">'</span>
				<span class="m-left">m</span>
				<span class="name">E</span>
				<span class="m-left name">u</span>
				<span class="m-left name">n</span>
				<span class="m-left name">i</span>
				<span class="m-left name">c</span>
				<span class="m-left name">e</span>
				<span class="m-left">'</span>
				<br>
				<span>W</span>
				<span class="m-left">e</span>
				<span class="m-left">b</span>
				<span>D</span>
				<span class="m-left">e</span>
				<span class="m-left">s</span>
				<span class="m-left">i</span>
				<span class="m-left">g</span>
				<span class="m-left">n</span>
				<span class="m-left">e</span>
				<span class="m-left">r</span>
				<span class="m-left">'</span>
			</h1>
			<p>CSS/Javascript/React</p>
			<a href="contact">Contact Me</a>
		</div>
		<div class="profile-image">
			<img src="<?php echo e(url('public/Pictures/profile.jpg')); ?>">
		</div>
	</div>

	<div id="about">
		<div class="about-me-info">
			<h3>Hello everyone,</h3>
			<p>Welcome to my About me Page! My name is Eunice Aquino. I'm 15 years old and I am currently taking up BS in Information Technology in Urdaneta City University.</p>
		</div>
	</div>

	<div id="contact">
		<div class="contact-info">
			<div><i class="fas fa-map-marker"></i>Urdaneta,Pangasinan</div>
			<div><i class="fas fa-envelope"></i>Eunice@gmail.com</div>
			<div><i class="fas fa-phone"></i>+63 9000 000 000</div>
			<div><i class="fas fa-clock"></i>Mon - Fri 8:00 AM to 5:00 PM</div>
		</div>
		<div class="contact-form">
			<h2>Contact Us</h2>
			<form class="contact" method="post">
				<input type="text" name="name" class="text-box" placeholder="Name">
				<input type="email" name="email" class="text-box" placeholder="Email">
				<textarea name="message" rows="5" placeholder="Message"></textarea>
				<input type="submit" name="submit" class="send-btn" value="submit">
			</form>
		</div>
	</div>

	<footer>
		<hr>
		<p>2021 Copyright. All rights Reserved.</p>
	</footer>
</body>
</html><?php /**PATH C:\Users\Patrick\OneDrive\Desktop\Portfolio\resources\views/home.blade.php ENDPATH**/ ?>