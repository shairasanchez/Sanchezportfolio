<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
    <title>Portfolio</title>
    <style type="text/css">
    	{
	margin: 0;
	padding: 0;
	box-sizing: border-box;
}
html{
	overflow-y: Scroll;
	scroll-behavior: smooth;
	scroll-snap-type: y mandatory;
}
body{
	font-family: 'PT Sans', sans-serif;
	height: 100vh;
}
header{
	position: fixed;
	top: 0;
	z-index: 1;
	display: flex;
	width: 100%;
	background: #0B3861;
	justify-content: flex-start;
}
header nav ul{
	display: flex;
	list-style: none;
}
header ul li{
	margin: 0 1rem;
	padding: 5px;
}
header ul li a{
	text-decoration: none;
	text-transform: uppercase;
	color: #fff;
}
header ul li a:hover{
	color: #ED5565;
}

#home{
	background: url("Pictures/first.jpg") no-repeat center center/cover;
	height: 100vh;
}
#home{
	display: flex;
	flex-direction: column;
	width: 100%;
	height: 100vh;
}
#home .profile-image{
	position: relative;
	width: 150px;
	height: 150px;
	top: 25%;
	left: 50%;
	border-radius: 50%;
	transform: translateX(-50%);
	background-color: rgba(3, 27, 96, 0.5);
}
.profile-image img{
	width: 140px;
	height: 140px;
	padding: 5px;
	border-radius: 50%;
}
#home h1{
	position: relative;
	justify-content: center;
	left: 25%;
	width: 50%;
	margin-top: 20%;
	padding: 5px, 5px;
	font-size: 2.7rem;
	text-align: center;
	color: #000;
	background-color: rgba(3, 27, 96, 0.5);
	border-radius: 30px;
}
span:hover{
	color: #fff;
	transition: all .5s;
}
span.name{
	color: #ED5565;
}
span.m-left{
	margin-left: -10px;
}
.text a{
	position: relative;
	text-decoration: none;
	font-size: .9rem;
	text-transform: uppercase;
	top: 5%;
	left: 35%;
	margin: 5px;
	padding: 7px 15px;
	background-color: none;
	border: 3px solid #031B60;
	color: #fff;
	letter-spacing: 3px;
	background-color: rgba(3, 27, 96, 0.85);
}

#about{
	background: url("Pictures/second.jpg") no-repeat center center/cover;
	height: 100vh;
}
#about .about-me-info{
	position: relative;
	top: 50%;
	left: 50%;
	transform: translate(-50%, -50%);
	width: 70%;
	padding: 10px 20px;
	font-family: cursive;
	border-radius: 20px;
	background-color: rgba(0,0,0,0.4);
	color: #fff;
	border: 2px inset #fff;
}
#about .about-me-info h3{
	letter-spacing: 3px;
	font-size: 35px;
	margin-bottom: 10px;
	color: #000;
}
#about .about-me-info p{
	font-size: 1.3rem;
	color: #fff;
}

#contact{
	background: url("Pictures/third.jpg") no-repeat center center/cover;
	min-height: 100vh;
	width: 100%;
	font-family: "Poppins", sans-serif;
	background-size: cover;
	display: flex;
	justify-content: center;
	align-items: center;
}
.contact-info{
	color: #000;
	max-width: 400px;
	line-height: 65px;
	padding-left: 50px;
	font-size: 18px;
}
.contact-info i{
	margin-right: 10px;
	font-size: 25px;
}
.contact-form{
	max-width: 500px;
	margin-right: 50px;
}
.contact-info, .contact-form{
	flex: 1;
}
.contact-form h2{
	color: #000;
	text-align: center;
	font-size: 35px;
	text-transform: uppercase;
	margin-bottom: 30px;
}
.contact-form .text-box{
	background: #000;
	color: #fff;
	border: none;
	width: 40%;
	height: 30px;
	padding: 10px;
	font-size: 15px;
	border-radius: 5px;
	box-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
	margin-bottom: 20px;
	opacity: 0.9;
}
.contact-form .text-box:first-child{
	margin-right: 15px;
}
.contact-form textarea{
	background: #000;
	color: #fff;
	border: none;
	width: 87%;
	padding: 12px;
	font-size: 15px;
	min-height: 200px;
	max-height: 400px;
	resize: vertical;
	border-radius: 5px;
	box-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
	margin-bottom: 20px;
	opacity: 0.9;
}
.contact-form .send-btn{
	float: right;
	margin-right: 38px;
	background: #2E94E3;
	color: #fff;
	border: none;
	width: 120px;
	height: 40px;
	font-size: 15px;
	font-weight: 600;
	text-transform: uppercase;
	letter-spacing: 2px;
	border-radius: 5px;
	cursor: pointer;
	transition: 0.3s;
	transition-property: background;
}
.contact-form .send-btn:hover{
	background: #0582E3;
}
footer{
	background-color: #0B3861;
	width: 100%;
	height: 40px;
}
footer p{
	text-align: center;
	color: #fff;
}

    </style>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet">
</head>
<body>
	<header>
		<nav>
			<ul>
				<li><a href="#home">Homepage</a></li>
				<li><a href="#about">About me Page</a></li>
				<li><a href="#contact">Contacts</a></li>
			</ul>
		</nav>
	</header>

	<div id="home">
		<div class="profile-image">
			<img src="Pictures/me.png">
		</div>
		<div class="text">
			<h1>
				<span>H</span>
				<span class="m-left">e</span>
				<span class="m-left">l</span>
				<span class="m-left">l</span>
				<span class="m-left">o</span>
				<span class="m-left">,</span>
				<br>
				<span>I</span>
				<span class="m-left">'</span>
				<span class="m-left">m</span>
				<span class="name">S</span>
				<span class="m-left name">h</span>
				<span class="m-left name">a</span>
				<span class="m-left name">i</span>
				<span class="m-left name">r</span>
				<span class="m-left name">a</span>
				<span class="name">S</span>
				<span class="m-left name">a</span>
				<span class="m-left name">n</span>
				<span class="m-left name">c</span>
				<span class="m-left name">h</span>
				<span class="m-left name">e</span>
				<span class="m-left name">z</span>
				<span class="m-left">'</span>
			</h1>
			<a href="#about">About Me</a>
			<a href="#contact">Contact Me</a>
		</div>
	</div>

	<div id="about">
		<div class="about-me-info">
			<h3>Hi!</h3>
			<p>My name is Shaira Reyes Sanchez but you can call me "Shai" or "Shaishai". I just turned 22 last September 24, 2020,
			I was born on the year of 1998 month of September and the day of 24, i was born in and currently living at Matarannoc, San Manuel, Tarlac.</p>
			<p>Currently taking up my bachelor's degree at Urdaneta City University. Third year College with a course of Bachelor of Science in Information Technology.</p>
		</div>
	</div>

	<div id="contact">
		<div class="contact-info">
			<div><i class="fas fa-map-marker"></i>San Manuel, Tarlac</div>
			<div><i class="fas fa-envelope"></i>Shaira@gmail.com</div>
			<div><i class="fas fa-phone"></i>+63 9000 000 000</div>
			<div><i class="fas fa-clock"></i>Mon - Fri 8:00 AM to 5:00 PM</div>
		</div>
		<div class="contact-form">
			<h2>Contact Us</h2>
			<form class="contact" method="post">
				<input type="text" name="name" class="text-box" placeholder="Name">
				<input type="email" name="email" class="text-box" placeholder="Email">
				<textarea name="message" rows="5" placeholder="Message"></textarea>
				<input type="submit" name="submit" class="send-btn" value="submit">
			</form>
		</div>
	</div>

	<footer>
		<hr>
		<p>SHAIRA SANCHEZ BSIT-3 BLOCK-3</p>
	</footer>
</body>
</html><?php /**PATH C:\xampp\htdocs\Laravel\Portfolio\resources\views/home.blade.php ENDPATH**/ ?>